text = input ("enter the string  ::")
x = text
y=text[::-1]
print (y)

if  x==y :
	print("text is pallindrome")
else :
	print("text is not pallindrome")
