#! /usr/bin/python 
print ("Hello World!")
print ("- From your friendly Python program")

import time
import webbrowser
import http.client
#import  BeautifulSoup
import urllib.request
 #import requests

with urllib.request.urlopen('http://www.google.com')
page = urllib.request.get("www.google.com")
status = page.status_code

print status

        #as response:
 	#html = response.read()

