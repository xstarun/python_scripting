from turtle import turtle
t= turtle()
for step in range (50):
         t.forward(500)
         t.right(180)

         