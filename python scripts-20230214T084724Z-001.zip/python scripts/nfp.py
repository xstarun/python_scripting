
"""

x = [1,2,3,5,7,6,-1]
y = [8,1,3,4,5,12,9,6,-1]
end =[]
for i in x:
	p =0
	if  x[-i] in [y]:
	  	end.append(p[i])
	  	p =p+1
	
	      	
print (end)	  	
"""

vowel = [1,2,3,4,5,6]
comb= []
for i in vowel:
	if vowel[i] == itr(comb):
	 vowel[i] = random(vowel)
	print(i)
