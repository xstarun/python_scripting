#! /usr/bin/python3

# import requests
# from bs4 import BeautifulSoup
import os
import datetime

dt =datetime.datetime.now()
print (dt)
ct = str(dt.year)+ " "+ str(dt.month)+" "+ str(dt.day)
print (ct)